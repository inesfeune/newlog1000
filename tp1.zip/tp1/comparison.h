


float comparison(float initial_value, float root);

